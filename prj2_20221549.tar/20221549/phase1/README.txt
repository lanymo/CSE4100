make로 컴파일한 후에, ./myshell을 입력하여 shell 실행이 가능하다.

1. exit, quit : shell에서 탈출한다
2. cd /경로 : cd를 이용해 경로를 이동할 수 있다. .. ' '(공백), 상대경로 및 절대경로 등이 인자 값으로 들어올 수 있다.
3. echo, vim, cat, ls, ls -al, mkdir, rmdir 등 리눅스 쉘에 존재하는 명령어를 사용할 수 있다.
